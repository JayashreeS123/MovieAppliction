export class Movie {
    id?: number;
    name?: string;
    rated?: number;
    released?: string;
    over_view?: string;
}
