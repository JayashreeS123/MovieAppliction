import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-all-list',
  templateUrl: './movie-all-list.component.html',
  styleUrls: ['./movie-all-list.component.css']
})
export class MovieAllListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
